﻿#Verzeichnis für bginfo in c:\Program Files (x86) erstellen
New-Item -Path "c:\Program Files (x86)\BGInfo" -ItemType directory
#bginfo und desktop.bgi kopieren
Copy-Item -Path ./BGInfo.exe -Destination "c:\Program Files (x86)\BGInfo"
Copy-Item -Path ./Desktop.bgi -Destination "c:\Program Files (x86)\BGInfo"
Copy-Item -Path ./BGInfo.lnk -Destination "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp" 
#registry key für hohe Bildschirmauflösung
New-Item -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers"
New-ItemProperty -Path "HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion\AppCompatFlags\Layers" -Name "C:\Program Files (x86)\BGInfo\BGInfo.exe" -PropertyType String -Value "~ HIGHDPIAWARE"
