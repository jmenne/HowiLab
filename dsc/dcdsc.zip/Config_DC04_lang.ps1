﻿configuration DCHydration
        {
            param 
            ( 
                [Parameter(Mandatory)] 
                [pscredential]$safemodeAdministratorCred, 
        
                [Parameter(Mandatory)] 
                [pscredential]$domainCred,

                [Parameter(Mandatory)]
                [pscredential]$NewADUserCred

            )

            Import-DscResource -ModuleName xActiveDirectory 
            Import-DSCResource -ModuleName xNetworking 
            Import-DSCResource -ModuleName xDHCPServer 
            Import-DscResource -ModuleName PSDesiredStateConfiguration
            Import-DscResource -ModuleName xComputerManagement

            Node $AllNodes.Nodename 

            {
                  xIPaddress IP
                {
                    IPAddress = $Node.IPAddress
                    AddressFamily = $Node.AddressFamily
                    InterfaceAlias = $Node.InterfaceAlias
                }

                xDefaultGatewayAddress SetDefaultGateway
                {
                    Address = $Node.DefaultGateway
                    InterfaceAlias = $Node.InterfaceAlias
                    AddressFamily  = $Node.AddressFamily
                    DependsOn = "[xIPAddress]IP"
                }
               
                # BGINFO
                File bginfopath
                {
                 Ensure = 'Present'
                 Type = 'Directory'
                 Recurse = $true
                 SourcePath = "c:\dsc\Install-bginfo"
                 DestinationPath = "c:\Program Files (x86)\BGInfo"
                }

                File bginfostartup
                { 
                 Ensure = 'Present'
                 Type = 'File'
                 SourcePath = "C:\dsc\Install-BGInfo\BGInfo.lnk"
                 DestinationPath = "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp\BGInfo.lnk"
                }

                  # Change Server Name
                  xComputer SetName { 
                  Name = $Node.MachineName 
                  }
                
                WindowsFeature ADDSInstall 
                { 
                    Ensure = "Present" 
                    Name = "AD-Domain-Services"
                    DependsOn = "[xIPAddress]IP"
                }

                WindowsFeature FeatureGPMC
                {
                    Ensure = "Present"
                    Name = "GPMC"
                    DependsOn = "[WindowsFeature]ADDSInstall"
                }

                WindowsFeature FeatureADPowerShell
                {
                    Ensure = "Present"
                    Name = "RSAT-AD-PowerShell"
                    DependsOn = "[WindowsFeature]ADDSInstall"
                } 

                WindowsFeature FeatureADAdminCenter
                {
                    Ensure = "Present"
                    Name = "RSAT-AD-AdminCenter"
                    DependsOn = "[WindowsFeature]ADDSInstall"
                } 

                WindowsFeature FeatureADDSTools
                {
                    Ensure = "Present"
                    Name = "RSAT-ADDS-Tools"
                    DependsOn = "[WindowsFeature]ADDSInstall"
                } 

                WindowsFeature FeatureDNSTools
                {
                    Ensure = "Present"
                    Name = "RSAT-DNS-Server"
                    DependsOn = "[WindowsFeature]ADDSInstall"
                } 
        
                xADDomain FirstDS 
                { 
                    DomainName = $Node.DomainName 
                    DomainAdministratorCredential = $domainCred 
                    SafemodeAdministratorPassword = $safemodeAdministratorCred
                    DomainNetbiosName = $node.DomainNetbiosName
                    DependsOn = "[WindowsFeature]ADDSInstall"
                } 
            
                xWaitForADDomain DscForestWait 
                { 
                    DomainName = $Node.DomainName 
                    DomainUserCredential = $domainCred 
                    RetryCount = $Node.RetryCount 
                    RetryIntervalSec = $Node.RetryIntervalSec 
                    DependsOn = "[xADDomain]FirstDS" 
                }
                
                xADOrganizationalUnit HowiLabOU
                {
                    Name = 'HowiLab'
                    Path = "DC=corp,DC=howilab,dc=local"
                    ProtectedFromAccidentalDeletion = $true
                    Ensure = 'Present'
                    DependsOn = "[xADDomain]FirstDS" 
                }

                xADOrganizationalUnit ClientsOU
                {
                    Name = 'Clients'
                    Path = "OU=howilab,DC=corp,DC=howilab,dc=local"
                    ProtectedFromAccidentalDeletion = $true
                    Ensure = 'Present'
                    DependsOn = "[xADOrganizationalUnit]HowiLabOU" 
                }

                xADOrganizationalUnit ServersOU
                {
                    Name = 'Servers'
                    Path = "OU=howilab,DC=corp,DC=howilab,dc=local"
                    ProtectedFromAccidentalDeletion = $true
                    Ensure = 'Present'
                    DependsOn = "[xADOrganizationalUnit]HowiLabOU" 
                }

                 xADOrganizationalUnit GroupsOU
                {
                    Name = 'Groups'
                    Path = "OU=howilab,DC=corp,DC=howilab,dc=local"
                    ProtectedFromAccidentalDeletion = $true
                    Ensure = 'Present'
                    DependsOn = "[xADOrganizationalUnit]HowiLabOU" 
                }
                
                xADOrganizationalUnit UsersOU
                {
                    Name = 'Users'
                    Path = "OU=howilab,DC=corp,DC=howilab,dc=local"
                    ProtectedFromAccidentalDeletion = $true
                    Ensure = 'Present'
                    DependsOn = "[xADOrganizationalUnit]HowiLabOU" 
                }
                
                xADUser Anna
                {
                    DomainName = $Node.DomainName
                    DomainAdministratorCredential = $domainCred
                    CommonName = "Anna Bolika"
                    UserName = "Anna"
                    GivenName = "Anna"
                    SurName = "Bolika"
                    Displayname = "Anna Bolika"
                    UserPrincipalName = "Anna@corp.howilab.local"
                    Company = "HowiLab"
                    Department = "Forschung"
                    Jobtitle ="Leitung"
                    Password = $DomainCreds
                    Ensure = "Present"
                    DependsOn = "[xADOrganizationalUnit]UsersOU"
                    Path = "OU=Users,OU=HowiLab,DC=corp,DC=howilab,DC=local"
                    PasswordNeverExpires = $true
                }

                xADUser Ellen
                {
                    DomainName = $Node.DomainName
                    DomainAdministratorCredential = $domainCred
                    CommonName = "Ellen Bogen"
                    UserName = "Ellen"
                    GivenName = "Ellen"
                    SurName = "Bogen"
                    Displayname = "Ellen Bogen"
                    UserPrincipalName = "Ellen@corp.howilab.local"
                    Company = "HowiLab"
                    Department = "IT"
                    Jobtitle = "Leitung"
                    Password = $DomainCreds
                    Ensure = "Present"
                    DependsOn = "[xADOrganizationalUnit]UsersOU"
                    Path = "OU=Users,OU=HowiLab,DC=corp,DC=howilab,DC=local"
                    PasswordNeverExpires = $true
                }

                xADUser Ansgar
                {
                    DomainName = $Node.DomainName
                    DomainAdministratorCredential = $domainCred
                    CommonName = "Ansgar Ragentor"
                    UserName = "Ansgar"
                    GivenName = "Ansgar"
                    SurName = "Ragentor"
                    Displayname = "Ansgar Ragentor"
                    UserPrincipalName = "Ansgar@corp.howilab.local"
                    Company = "HowiLab"
                    Department = "Forschung"
                    Jobtitle = "Mitarbeiter"
                    Password = $DomainCreds
                    Ensure = "Present"
                    DependsOn = "[xADOrganizationalUnit]UsersOU"
                    Path = "OU=Users,OU=HowiLab,DC=corp,DC=howilab,DC=local"
                    PasswordNeverExpires = $true
                }

                xADUser Erkan
                {
                    DomainName = $Node.DomainName
                    DomainAdministratorCredential = $domainCred
                    CommonName = "Erkan Nichtanders"
                    UserName = "Erkan"
                    GivenName = "Erkan"
                    SurName = "Nichtanders"
                    Displayname = "Erkan Nichtanders"
                    UserPrincipalName = "Erkan@corp.howilab.local"
                    Company = "HowiLab"
                    Department = "IT"
                    Jobtitle = "Mitarbeiter"
                    Password = $DomainCreds
                    Ensure = "Present"
                    DependsOn = "[xADOrganizationalUnit]UsersOU"
                    Path = "OU=Users,OU=HowiLab,DC=corp,DC=howilab,DC=local"
                    PasswordNeverExpires = $true
                 }

                xADUser Ben
                {
                    DomainName = $Node.DomainName
                    DomainAdministratorCredential = $domainCred
                    CommonName = "Ben Utzer"
                    UserName = "Ben"
                    GivenName = "Ben"
                    SurName = "Utzer"
                    Displayname = "Ben Utzer"
                    UserPrincipalName = "Ben@corp.howilab.local"
                    Company = "HowiLab"
                    Department = "HelpDesk"
                    Jobtitle = "Mitarbeiter"
                    Password = $DomainCreds
                    Ensure = "Present"
                    DependsOn = "[xADOrganizationalUnit]UsersOU"
                    Path = "OU=Users,OU=HowiLab,DC=corp,DC=howilab,DC=local"
                    PasswordNeverExpires = $true
                 }

                xADUser Lasse
                {
                    DomainName = $Node.DomainName
                    DomainAdministratorCredential = $domainCred
                    CommonName = "Lasse Reden"
                    UserName = "Lasse"
                    GivenName = "Lasse"
                    SurName = "Reden"
                    Displayname = "Lasse Reden"
                    UserPrincipalName = "Lasse@corp.howilab.local"
                    Company = "HowiLab"
                    Department = "HelpDesk"
                    Jobtitle = "Leitung"
                    Password = $DomainCreds
                    Ensure = "Present"
                    DependsOn = "[xADOrganizationalUnit]UsersOU"
                    Path = "OU=Users,OU=HowiLab,DC=corp,DC=howilab,DC=local"
                    PasswordNeverExpires = $true
                 }

                xADUser Claudia
                {
                    DomainName = $Node.DomainName
                    DomainAdministratorCredential = $domainCred
                    CommonName = "Claudia Manten"
                    UserName = "Claudia"
                    GivenName = "Claudia"
                    SurName = "Reden"
                    Displayname = "Claudia Manten"
                    UserPrincipalName = "Claudia@corp.howilab.local"
                    Company = "HowiLab"
                    Department = "Vertrieb"
                    Jobtitle = "Leitung"
                    Password = $DomainCreds
                    Ensure = "Present"
                    DependsOn = "[xADOrganizationalUnit]UsersOU"
                    Path = "OU=Users,OU=HowiLab,DC=corp,DC=howilab,DC=local"
                    PasswordNeverExpires = $true
                 }

                xADUser Theo
                {
                    DomainName = $Node.DomainName
                    DomainAdministratorCredential = $domainCred
                    CommonName = "Theo Retisch"
                    UserName = "Theo"
                    GivenName = "Theo"
                    SurName = "Retisch"
                    Displayname = "Theo Retisch"
                    UserPrincipalName = "Theo@corp.howilab.local"
                    Company = "HowiLab"
                    Department = "Vertrieb"
                    Jobtitle = "Mitarbeiter"
                    Password = $DomainCreds
                    Ensure = "Present"
                    DependsOn = "[xADOrganizationalUnit]UsersOU"
                    Path = "OU=Users,OU=HowiLab,DC=corp,DC=howilab,DC=local"
                    PasswordNeverExpires = $true
                 }   

                xADUser Ed
                {
                    DomainName = $Node.DomainName
                    DomainAdministratorCredential = $domainCred
                    CommonName = "Ed Was"
                    UserName = "Ed"
                    GivenName = "Ed"
                    SurName = "Was"
                    Displayname = "Ed Was"
                    UserPrincipalName = "Ed@corp.howilab.local"
                    Company = "HowiLab"
                    Department = "Buchhaltung"
                    Jobtitle = "Mitarbeiter"
                    Password = $DomainCreds
                    Ensure = "Present"
                    DependsOn = "[xADOrganizationalUnit]UsersOU"
                    Path = "OU=Users,OU=HowiLab,DC=corp,DC=howilab,DC=local"
                    PasswordNeverExpires = $true
                 }

                xADUser Gesa
                {
                    DomainName = $Node.DomainName
                    DomainAdministratorCredential = $domainCred
                    CommonName = "Gesa Melte-Werke"
                    UserName = "Gesa"
                    GivenName = "Gesa"
                    SurName = "Melte-Werke"
                    Displayname = "Gesa Melte-Werke"
                    UserPrincipalName = "Gesa@corp.howilab.local"
                    Company = "HowiLab"
                    Department = "Buchhaltung"
                    Jobtitle = "Leitung"
                    Password = $DomainCreds
                    Ensure = "Present"
                    DependsOn = "[xADOrganizationalUnit]UsersOU"
                    Path = "OU=Users,OU=HowiLab,DC=corp,DC=howilab,DC=local"
                    PasswordNeverExpires = $true
                 }

                xADUser Heinz
                {
                    DomainName = $Node.DomainName
                    DomainAdministratorCredential = $domainCred
                    CommonName = "Heinz Ellmann"
                    UserName = "Heinz"
                    GivenName = "Heinz"
                    SurName = "Ellmann"
                    Displayname = "Heinz Ellmann"
                    UserPrincipalName = "Heinz@corp.howilab.local"
                    Company = "HowiLab"
                    Department = "Management"
                    Jobtitle = "Mitarbeiter"
                    Password = $DomainCreds
                    Ensure = "Present"
                    DependsOn = "[xADOrganizationalUnit]UsersOU"
                    Path = "OU=Users,OU=HowiLab,DC=corp,DC=howilab,DC=local"
                    PasswordNeverExpires = $true
                 }

                xADUser Jack
                {
                    DomainName = $Node.DomainName
                    DomainAdministratorCredential = $domainCred
                    CommonName = "Jack Pott"
                    UserName = "Jack"
                    GivenName = "Jack"
                    SurName = "Pott"
                    Displayname = "Jack Pott"
                    UserPrincipalName = "Jack@corp.howilab.local"
                    Company = "HowiLab"
                    Department = "Management"
                    Jobtitle = "Leitung"
                    Password = $DomainCreds
                    Ensure = "Present"
                    DependsOn = "[xADOrganizationalUnit]UsersOU"
                    Path = "OU=Users,OU=HowiLab,DC=corp,DC=howilab,DC=local"
                    PasswordNeverExpires = $true
                 }

                xADGroup 'Forschung'
                {
                  Ensure       = 'Present'
                  GroupName    = 'Forschung'
                  Path         = "OU=Groups,OU=HowiLab,DC=corp,DC=howilab,DC=local"
                  GroupScope   = 'Global'
                  Category     = 'Security'
                  Description  = "Mitarbeiter der Forschungsabteilung"
                  MembersToInclude = "Anna","Ansgar"
                  DependsOn    = "[xADOrganizationalUnit]GroupsOU"
                }
                
                xADGroup 'IT'
                {
                  Ensure       = 'Present'
                  GroupName    = 'IT'
                  Path         = "OU=Groups,OU=HowiLab,DC=corp,DC=howilab,DC=local"
                  GroupScope   = 'Global'
                  Category     = 'Security'
                  Description  = "Mitarbeiter der IT-Abteilung"
                  MembersToInclude = "Ellen","Erkan"
                  DependsOn    = "[xADOrganizationalUnit]GroupsOU"
                }

                xADGroup 'HelpDesk'
                {
                  Ensure       = 'Present'
                  GroupName    = 'HelpDesk'
                  Path         = "OU=Groups,OU=HowiLab,DC=corp,DC=howilab,DC=local"
                  GroupScope   = 'Global'
                  Category     = 'Security'
                  Description  = "Mitarbeiter der Abteilung HelpDesk"
                  MembersToInclude = "Lasse","Ben"
                  DependsOn    = "[xADOrganizationalUnit]GroupsOU"
                }

                xADGroup 'Management'
                {
                  Ensure       = 'Present'
                  GroupName    = 'Management'
                  Path         = "OU=Groups,OU=HowiLab,DC=corp,DC=howilab,DC=local"
                  GroupScope   = 'Global'
                  Category     = 'Security'
                  Description  = "Mitarbeiter der Abteilung Management"
                  MembersToInclude = "Heinz","Jack"
                  DependsOn    = "[xADOrganizationalUnit]GroupsOU"
                }

                xADGroup 'Vertrieb'
                {
                  Ensure       = 'Present'
                  GroupName    = 'Vertrieb'
                  Path         = "OU=Groups,OU=HowiLab,DC=corp,DC=howilab,DC=local"
                  GroupScope   = 'Global'
                  Category     = 'Security'
                  Description  = "Mitarbeiter der Abteilung Vertrieb"
                  MembersToInclude = "Claudia","Theo"
                  DependsOn    = "[xADOrganizationalUnit]GroupsOU"
                }

                xADGroup 'Buchhaltung'
                {
                  Ensure       = 'Present'
                  GroupName    = 'Buchhaltung'
                  Path         = "OU=Groups,OU=HowiLab,DC=corp,DC=howilab,DC=local"
                  GroupScope   = 'Global'
                  Category     = 'Security'
                  Description  = "Mitarbeiter der Abteilung Buchhaltung"
                  MembersToInclude = "Ed","Gesa"
                  DependsOn    = "[xADOrganizationalUnit]GroupsOU"
                }

                xADGroup 'EWS'
                {
                  Ensure       = 'Present'
                  GroupName    = 'EWS'
                  Path         = "OU=Groups,OU=HowiLab,DC=corp,DC=howilab,DC=local"
                  GroupScope   = 'Global'
                  Category     = 'Security'
                  Description  = "Alle User sollen sich per RDP am Client anmelden können"
                  MembersToInclude = "Ed","Gesa","Claudia","Theo","Heinz","Jack","Lasse","Ben","Ellen","Erkan","Anna","Ansgar"
                  DependsOn    = "[xADOrganizationalUnit]GroupsOU"
                }
               
                xADUser AdministratorNeverExpires
                {
                    DomainName = $Node.DomainName
                    UserName = "Administrator"
                    Ensure = "Present"
                    DependsOn = "[xADDomain]FirstDS"
                    PasswordNeverExpires = $true
                }
       
                WindowsFeature DHCPServer
                {
                    Ensure = "Present"
                    Name = "DHCP"
                    DependsOn = "[xADDomain]FirstDS"
                }

                Service DHCPServer 
                {
                    Name = "DHCPServer"
                    State = "Running"
                    DependsOn =  "[WindowsFeature]DHCPServer"
                }

                WindowsFeature DHCPServerManagement
                {
                    Ensure = "Present"
                    Name = "RSAT-DHCP"
                    DependsOn = "[WindowsFeature]DHCPServer"
                } 

                xDhcpServerScope HowiLabScope
                {
                    Ensure = 'Present'
                    ScopeID = '172.16.0.0'
                    IPStartRange = '172.16.0.50'
                    IPEndRange = '172.16.0.99'
                    Name = 'HowiLab'
                    SubnetMask = '255.255.255.0'
                    LeaseDuration = '00:08:00'
                    State = 'Active'
                    AddressFamily = 'IPv4'
                    DependsOn = "[Service]DHCPServer"
                }

                DhcpScopeOptionValue 'ScopeOptionGateway'
                {
                    OptionId      = 3
                    Value         = '172.16.0.1'
                    ScopeId       = '172.16.0.0'
                    VendorClass   = ''
                    UserClass     = ''
                    AddressFamily = 'IPv4'
                    DependsOn = "[Service]DHCPServer"
                }

                # Setting scope DNS servers
                DhcpScopeOptionValue 'ScopeOptionDNS'
                {
                    OptionId      = 6
                    #Value         = @('172.16.0.13')
                    Value         = @(($Node.IPAddress -split "/")[0])
                    ScopeId       = '172.16.0.0'
                    VendorClass   = ''
                    UserClass     = ''
                    AddressFamily = 'IPv4'
                    DependsOn = "[Service]DHCPServer"
                }

                # Setting scope DNS domain name
                DhcpScopeOptionValue 'ScopeOptionDNSDomainName'
                {
                    OptionId      = 15
                    Value         = $Node.DomainName
                    ScopeId       = '172.16.0.0'
                    VendorClass   = ''
                    UserClass     = ''
                    AddressFamily = 'IPv4'
                    DependsOn = "[Service]DHCPServer"
                }
                                
                xDhcpServerAuthorization LocalServerActivation
                {
                    Ensure = 'Present'
                    IsSingleInstance = 'Yes'
                }

                WindowsFeature DSCServiceFeature
                {
                    Ensure = "Present"
                    Name   = "DSC-Service"
                }

            }
        }
