﻿#create LCM config
[DSCLocalConfigurationManager()]          
configuration LCMConfig {
    Node localhost {
        Settings
        {
         RebootNodeIfNeeded = $true
         ActionAfterReboot = 'ContinueConfiguration'
         ConfigurationMode = 'ApplyOnly'
         RefreshMode = 'Push'   
        }
    }
}