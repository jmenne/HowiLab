﻿configuration DCHydration
        {
            param 
            ( 
                [Parameter(Mandatory)] 
                [pscredential]$safemodeAdministratorCred, 
        
                [Parameter(Mandatory)] 
                [pscredential]$domainCred,

                [Parameter(Mandatory)]
                [pscredential]$NewADUserCred

            )

            Import-DscResource -ModuleName xActiveDirectory 
            Import-DSCResource -ModuleName xNetworking 
            Import-DSCResource -ModuleName xDHCPServer 
            Import-DscResource -ModuleName PSDesiredStateConfiguration
            Import-DscResource -ModuleName xComputerManagement

            Node $AllNodes.Nodename 

            {
                  xIPaddress IP
                {
                    IPAddress = $Node.IPAddress
                    AddressFamily = $Node.AddressFamily
                    InterfaceAlias = $Node.InterfaceAlias
                }

                xDefaultGatewayAddress SetDefaultGateway
                {
                    Address = $Node.DefaultGateway
                    InterfaceAlias = $Node.InterfaceAlias
                    AddressFamily  = $Node.AddressFamily
                    DependsOn = "[xIPAddress]IP"
                }
               
                # BGINFO
                File bginfopath
                {
                 Ensure = 'Present'
                 Type = 'Directory'
                 Recurse = $true
                 SourcePath = "c:\dsc\Install-bginfo"
                 DestinationPath = "c:\Program Files (x86)\BGInfo"
                }

                File bginfostartup
                { 
                 Ensure = 'Present'
                 Type = 'File'
                 SourcePath = "C:\dsc\Install-BGInfo\BGInfo.lnk"
                 DestinationPath = "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp\BGInfo.lnk"
                }

                  # Change Server Name
                  xComputer SetName { 
                  Name = $Node.MachineName 
                  }
                
                WindowsFeature ADDSInstall 
                { 
                    Ensure = "Present" 
                    Name = "AD-Domain-Services"
                    DependsOn = "[xIPAddress]IP"
                }

                WindowsFeature FeatureGPMC
                {
                    Ensure = "Present"
                    Name = "GPMC"
                    DependsOn = "[WindowsFeature]ADDSInstall"
                }

                WindowsFeature FeatureADPowerShell
                {
                    Ensure = "Present"
                    Name = "RSAT-AD-PowerShell"
                    DependsOn = "[WindowsFeature]ADDSInstall"
                } 

                WindowsFeature FeatureADAdminCenter
                {
                    Ensure = "Present"
                    Name = "RSAT-AD-AdminCenter"
                    DependsOn = "[WindowsFeature]ADDSInstall"
                } 

                WindowsFeature FeatureADDSTools
                {
                    Ensure = "Present"
                    Name = "RSAT-ADDS-Tools"
                    DependsOn = "[WindowsFeature]ADDSInstall"
                } 

                WindowsFeature FeatureDNSTools
                {
                    Ensure = "Present"
                    Name = "RSAT-DNS-Server"
                    DependsOn = "[WindowsFeature]ADDSInstall"
                } 
        
                xADDomain FirstDS 
                { 
                    DomainName = $Node.DomainName 
                    DomainAdministratorCredential = $domainCred 
                    SafemodeAdministratorPassword = $safemodeAdministratorCred
                    DomainNetbiosName = $node.DomainNetbiosName
                    DependsOn = "[WindowsFeature]ADDSInstall"
                } 
            
                xWaitForADDomain DscForestWait 
                { 
                    DomainName = $Node.DomainName 
                    DomainUserCredential = $domainCred 
                    RetryCount = $Node.RetryCount 
                    RetryIntervalSec = $Node.RetryIntervalSec 
                    DependsOn = "[xADDomain]FirstDS" 
                }
                
                xADOrganizationalUnit HowiLabOU
                {
                    Name = 'HowiLab'
                    Path = "DC=corp,DC=howilab,dc=local"
                    ProtectedFromAccidentalDeletion = $true
                    Ensure = 'Present'
                    DependsOn = "[xADDomain]FirstDS" 
                }
                
                $OUNames = @("Clients","Servers","Users","Groups")
                Foreach ($OU in $OUNames) {
                    $ResName = $OU+"OU"
                    xADOrganizationalUnit $ResName
                    {
                        Name = $OU
                        Path = "OU=howilab,DC=corp,DC=howilab,dc=local"
                        ProtectedFromAccidentalDeletion = $true
                        Ensure = 'Present'
                        DependsOn = "[xADOrganizationalUnit]HowiLabOU" 
                    }
                }
                
                $NewUsers = Import-Csv -Path .\adusers.txt
                foreach ($user in $NewUsers) {
                    $FullName = $user.GivenName +" "+ $User.Surname
                    $UPN = $User.GivenName+"@"+$Node.DomainName

                    xADUser $User.GivenName
                    {
                        DomainName = $Node.DomainName
                        DomainAdministratorCredential = $domainCred
                        CommonName = $FullName
                        UserName = $User.GivenName
                        GivenName = $User.GivenName
                        SurName = $User.SurName
                        Displayname = $FullName
                        UserPrincipalName = $UPN
                        Company = "HowiLab"
                        Department = $User.Department
                        Jobtitle = $User.Title
                        Password = $DomainCreds
                        Ensure = "Present"
                        DependsOn = "[xADOrganizationalUnit]UsersOU"
                        Path = "OU=Users,OU=HowiLab,DC=corp,DC=howilab,DC=local"
                        PasswordNeverExpires = $true
                    }
                }
                
                $GroupNames = @("Forschung","IT","HelpDesk","Management","Vertrieb","Buchhaltung")
                foreach ($GroupName in $GroupNames) {
                    $members = $newusers | Where-Object Department -EQ $Groupname
                   
                    xADGroup $GroupName
                    {
                        Ensure       = 'Present'
                        GroupName    = $GroupName
                        Path         = "OU=Groups,OU=HowiLab,DC=corp,DC=howilab,DC=local"
                        GroupScope   = 'Global'
                        Category     = 'Security'
                        Description  = "Mitarbeiter der Abteilung $GroupName"
                        MembersToInclude = $members.GivenName
                        DependsOn    = "[xADOrganizationalUnit]GroupsOU"
                    }
                 
                }              

                xADGroup 'EWS'
                {
                  Ensure       = 'Present'
                  GroupName    = 'EWS'
                  Path         = "OU=Groups,OU=HowiLab,DC=corp,DC=howilab,DC=local"
                  GroupScope   = 'Global'
                  Category     = 'Security'
                  Description  = "Alle User sollen sich per RDP am Client anmelden können"
                  MembersToInclude = "Ed","Gesa","Claudia","Theo","Heinz","Jack","Lasse","Ben","Ellen","Erkan","Anna","Ansgar"
                  DependsOn    = "[xADOrganizationalUnit]GroupsOU"
                }
               
                xADUser AdministratorNeverExpires
                {
                    DomainName = $Node.DomainName
                    UserName = "Administrator"
                    Ensure = "Present"
                    DependsOn = "[xADDomain]FirstDS"
                    PasswordNeverExpires = $true
                }
       
                WindowsFeature DHCPServer
                {
                    Ensure = "Present"
                    Name = "DHCP"
                    DependsOn = "[xADDomain]FirstDS"
                }

                Service DHCPServer 
                {
                    Name = "DHCPServer"
                    State = "Running"
                    DependsOn =  "[WindowsFeature]DHCPServer"
                }

                WindowsFeature DHCPServerManagement
                {
                    Ensure = "Present"
                    Name = "RSAT-DHCP"
                    DependsOn = "[WindowsFeature]DHCPServer"
                } 

                xDhcpServerScope HowiLabScope
                {
                    Ensure = 'Present'
                    ScopeID = '172.16.0.0'
                    IPStartRange = '172.16.0.50'
                    IPEndRange = '172.16.0.99'
                    Name = 'HowiLab'
                    SubnetMask = '255.255.255.0'
                    LeaseDuration = '00:08:00'
                    State = 'Active'
                    AddressFamily = 'IPv4'
                    DependsOn = "[Service]DHCPServer"
                }

                DhcpScopeOptionValue 'ScopeOptionGateway'
                {
                    OptionId      = 3
                    Value         = '172.16.0.1'
                    ScopeId       = '172.16.0.0'
                    VendorClass   = ''
                    UserClass     = ''
                    AddressFamily = 'IPv4'
                    DependsOn = "[Service]DHCPServer"
                }

                # Setting scope DNS servers
                DhcpScopeOptionValue 'ScopeOptionDNS'
                {
                    OptionId      = 6
                    #Value         = @('172.16.0.13')
                    Value         = @(($Node.IPAddress -split "/")[0])
                    ScopeId       = '172.16.0.0'
                    VendorClass   = ''
                    UserClass     = ''
                    AddressFamily = 'IPv4'
                    DependsOn = "[Service]DHCPServer"
                }

                # Setting scope DNS domain name
                DhcpScopeOptionValue 'ScopeOptionDNSDomainName'
                {
                    OptionId      = 15
                    Value         = $Node.DomainName
                    ScopeId       = '172.16.0.0'
                    VendorClass   = ''
                    UserClass     = ''
                    AddressFamily = 'IPv4'
                    DependsOn = "[Service]DHCPServer"
                }
                                
                xDhcpServerAuthorization LocalServerActivation
                {
                    Ensure = 'Present'
                    IsSingleInstance = 'Yes'
                }

                WindowsFeature DSCServiceFeature
                {
                    Ensure = "Present"
                    Name   = "DSC-Service"
                }

            }
        }
