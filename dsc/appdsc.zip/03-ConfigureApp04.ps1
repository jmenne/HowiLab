﻿#Create credentials for App

. .\Config_App04.ps1
$username = "corp\Administrator"
$password = 'Pa$$w0rd' | ConvertTo-SecureString -asPlainText -Force
$cred = new-object System.Management.Automation.PSCredential ($username,$password)
    
#create DSC MOF files
AppConfig -ConfigurationData .\Configdata_App04.psd1 -OutputPath "c:\DSC\config" -domainCred $cred

# Start-DscConfiguration -Wait -Force -Path "c:\DSC\Config" -Verbose 
