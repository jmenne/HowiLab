﻿# Configure LCM

. .\lcmconfig.ps1
LCMconfig -OutputPath "c:\DSC\config"

Set-DscLocalConfigurationManager -Path "c:\dsc\config"
