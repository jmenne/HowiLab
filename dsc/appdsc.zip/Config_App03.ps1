﻿configuration AppConfig
        {
            param 
            ( 
                [Parameter(Mandatory)] 
                [pscredential]$domainCred
            )

            Import-DscResource -ModuleName xSmbShare 
            Import-DSCResource -ModuleName xNetworking 
            Import-DscResource -ModuleName PSDesiredStateConfiguration
            Import-DscResource -ModuleName xComputerManagement
            Import-DscResource -ModuleName xDSCDomainjoin

            Node $AllNodes.Nodename 

            {
                  xIPaddress IP
                {
                    IPAddress = $Node.IPAddress
                    AddressFamily = $Node.AddressFamily
                    InterfaceAlias = $Node.InterfaceAlias
                }

                xDefaultGatewayAddress SetDefaultGateway
                {
                    Address = $Node.DefaultGateway
                    InterfaceAlias = $Node.InterfaceAlias
                    AddressFamily  = $Node.AddressFamily
                    DependsOn = "[xIPAddress]IP"
                }

                xDnsServerAddress DnsServerAddress
                {
                    Address        = $Node.DNSServer
                    InterfaceAlias = 'Ethernet'
                    AddressFamily  = 'IPv4'
                    Validate       = $false
                    DependsOn = "[xIPAddress]IP"
                }
               
                # BGINFO
                File bginfopath
                {
                 Ensure = 'Present'
                 Type = 'Directory'
                 Recurse = $true
                 SourcePath = "c:\dsc\Install-bginfo"
                 DestinationPath = "c:\Program Files (x86)\BGInfo"
                }

                File bginfostartup
                { 
                 Ensure = 'Present'
                 Type = 'File'
                 SourcePath = "C:\dsc\Install-BGInfo\BGInfo.lnk"
                 DestinationPath = "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp\BGInfo.lnk"
                }

                 # Change Server Name
                 xComputer SetName { 
                 Name = $Node.MachineName 
                 }
                
                xDSCDomainjoin JoinDomain
                {
                 Domain = $Node.DomainName
                 Credential = $domainCred
                 JoinOU = "OU=Servers,OU=HowiLab,DC=corp,DC=howilab,dc=local"         
                }

                # Install IIS role 
                WindowsFeature IIS 
                { 
                 Ensure  = “Present” 
                 Name    = “Web-Server” 
                } 
 
                # Install ASP .NET 4.5 role 
                WindowsFeature AspNet45 
                { 
                 Ensure  = “Present” 
                 Name    = “Web-Asp-Net45” 
                }
    
                # Install IIS management tools       
                WindowsFeature IISManagementTools
                {
                 Name = 'Web-Mgmt-Tools'
                 Ensure = 'Present'
                 DependsOn = '[WindowsFeature]IIS'
                }           

                # Create folder
                File NewFolder {
                 Type = 'Directory'
                 DestinationPath = 'C:\Files'
                 Ensure = "Present"
                }

                # Create file
                File AddFile {
                 DestinationPath = 'C:\Files\Beispiel.txt'
                 Ensure = "Present"
                 Contents = ''
                }

                # Share folder
                 xSmbShare ShareFolder {
                 Ensure = 'Present'
                 Name   = 'Files'
                 Path = 'C:\Files'
                 FullAccess = 'Jeder'
                 DependsOn = '[File]NewFolder'
                }
      
                WindowsFeature DSCServiceFeature
                {
                    Ensure = "Present"
                    Name   = "DSC-Service"
                }

            }
        }
